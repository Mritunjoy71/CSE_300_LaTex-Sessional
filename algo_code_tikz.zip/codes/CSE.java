public class CSE {
    private String fullName;
    private int totalStudents;
    private int totalBatch;
    private String location;

    // you can't have any public/private setter methods for the above variables
    // you can have only one constructor of CSE
}

